<x-app-layout>
    <div class="container py-12">
        @livewire('create-category')
    </div>
</x-app-layout>
