<?php return array (
  'create-category' => 'App\\Http\\Livewire\\CreateCategory',
  'create-product' => 'App\\Http\\Livewire\\CreateProduct',
  'edit-product' => 'App\\Http\\Livewire\\EditProduct',
  'show-category' => 'App\\Http\\Livewire\\ShowCategory',
  'show-products' => 'App\\Http\\Livewire\\ShowProducts',
);