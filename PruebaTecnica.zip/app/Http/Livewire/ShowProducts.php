<?php

namespace App\Http\Livewire;

use App\Models\Product;
use Livewire\Component;
use Livewire\WithPagination;

class ShowProducts extends Component{
    use WithPagination;

    public $search;

    //Cada vez que se modifique la propiedad search
    public function updatingSearch(){
        $this->resetPage();
    }

    public function render(){

        $products = Product::where('name', 'like', '%' . $this->search . '%')->paginate(10);

        return view('livewire.show-products', compact('products'))->layout('layouts.app');
    }
}
